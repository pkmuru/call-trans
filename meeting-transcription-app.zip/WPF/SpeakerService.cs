using Microsoft.CognitiveServices.Speech;
using Microsoft.CognitiveServices.Speech.Audio;
using Microsoft.CognitiveServices.Speech.Transcription;
using NAudio.CoreAudioApi;
using NAudio.Wave;
using System;
using System.Threading.Tasks;

namespace MeetingTranscriptionApp
{
    public class SpeakerService : IDisposable
    {
        private WasapiLoopbackCapture capture;
        private PushAudioInputStream pushStream;
        private ConversationTranscriber recognizer;

        // Speaker color for visual distinction
        private readonly string SpeakerColor = "#D83B01"; // Orange for system audio
        
        // Event for transcription results
        public event EventHandler<TranscriptionEventArgs> TranscriptionReceived;
        public event EventHandler<IntermediateTranscriptionEventArgs> IntermediateTranscriptionReceived;
        public event Action<string> ErrorOccurred;
        public MMDevice AudioDevice { get; private set; }

        private readonly SpeechConfig speechConfig;

        public SpeakerService(SpeechConfig speechConfig)
        {
            this.speechConfig = speechConfig;
        }

        public async Task SetDeviceAsync(MMDevice device)
        {
            // Store the device for later use
            AudioDevice = device;
        }

        public async Task StartRecordingAsync(System.Threading.CancellationToken cancellationToken)
        {
            try
            {
                // Configure speech settings
                speechConfig.OutputFormat = OutputFormat.Detailed;
                speechConfig.SetProfanity(ProfanityOption.Removed);
                speechConfig.SetProperty("SpeechServiceResponse_SpeakerDiarizationEnabled", "true");
                speechConfig.SetProperty(PropertyId.Conversation_Initial_Silence_Timeout, "45000");
                speechConfig.SetProperty(PropertyId.SpeechServiceConnection_InitialSilenceTimeoutMs, "45000");
                speechConfig.SetProperty(PropertyId.SpeechServiceResponse_DiarizeIntermediateResults, "true");
                speechConfig.EnableDictation();

                // Create audio stream
                var audioFormat = AudioStreamFormat.GetWaveFormatPCM(16000, 16, 1);
                pushStream = AudioInputStream.CreatePushStream(audioFormat);
                var audioConfig = AudioConfig.FromStreamInput(pushStream);
                
                // Create conversation transcriber
                recognizer = new ConversationTranscriber(speechConfig, audioConfig);

                // Set up event handlers for final transcription
                recognizer.Transcribed += (s, e) =>
                {
                    if (!string.IsNullOrWhiteSpace(e.Result.Text))
                    {
                        ProcessTranscriptionResult(e.Result, false);
                    }
                };

                // Set up event handlers for intermediate transcription
                recognizer.Transcribing += (s, e) =>
                {
                    if (!string.IsNullOrWhiteSpace(e.Result.Text))
                    {
                        ProcessTranscriptionResult(e.Result, true);
                    }
                };

                recognizer.Canceled += (s, e) =>
                {
                    ErrorOccurred?.Invoke($"Canceled: {e.Reason} - {e.ErrorDetails}");
                };

                // Start transcribing
                await recognizer.StartTranscribingAsync();

                // Initialize audio capture
                capture = new WasapiLoopbackCapture(AudioDevice);

                // Set up data available handler
                capture.DataAvailable += (s, a) =>
                {
                    try
                    {
                        if (!cancellationToken.IsCancellationRequested)
                        {
                            byte[] buffer = new byte[a.BytesRecorded];
                            Array.Copy(a.Buffer, 0, buffer, 0, a.BytesRecorded);
                            pushStream.Write(buffer);
                        }
                    }
                    catch (Exception ex)
                    {
                        ErrorOccurred?.Invoke($"System Audio Write Error: {ex.Message}");
                    }
                };

                // Start recording
                capture.StartRecording();
            }
            catch (Exception ex)
            {
                ErrorOccurred?.Invoke($"System Audio Capture Error: {ex.Message}");
                throw;
            }
        }

        public async Task StopRecordingAsync()
        {
            try
            {
                // Stop and dispose capture
                if (capture != null)
                {
                    capture.StopRecording();
                    capture.Dispose();
                    capture = null;
                }

                // Close push stream
                if (pushStream != null)
                {
                    pushStream.Close();
                    pushStream = null;
                }

                // Stop and dispose recognizer
                if (recognizer != null)
                {
                    await recognizer.StopTranscribingAsync();
                    recognizer.Dispose();
                    recognizer = null;
                }
            }
            catch (Exception ex)
            {
                ErrorOccurred?.Invoke($"Error stopping speaker recording: {ex.Message}");
                throw;
            }
        }

        private void ProcessTranscriptionResult(ConversationTranscriptionResult result, bool isIntermediate)
        {
            try
            {
                // Default values
                string speakerName = AudioDevice?.FriendlyName ?? "System Audio";
                string speakerInitials = "SPK";
                int offset = 0;
                
                // Get speaker information directly from the result
                if (!string.IsNullOrEmpty(result.SpeakerId))
                {
                    speakerName = $"Speaker {result.SpeakerId}";
                    speakerInitials = $"S{result.SpeakerId}";
                }
                
                // Get offset in ticks if available
                if (result.OffsetInTicks > 0)
                {
                    // Convert ticks to milliseconds if needed
                    offset = (int)(result.OffsetInTicks / TimeSpan.TicksPerMillisecond);
                }
                
                // For intermediate results, we might want to indicate this is in progress
                if (isIntermediate)
                {
                    speakerName = !string.IsNullOrEmpty(result.SpeakerId) 
                        ? $"Speaker {result.SpeakerId} (typing...)" 
                        : "Transcribing...";
                }

                // Create transcription entry
                var entry = new TranscriptionEntry
                {
                    SpeakerName = speakerName,
                    SpeakerInitials = speakerInitials,
                    SpeakerColor = SpeakerColor,
                    Text = result.Text,
                    Timestamp = DateTime.Now.ToString("h:mm:ss tt"),
                    Offset = offset,
                    IsIntermediate = isIntermediate
                };

                // Raise appropriate event based on whether this is intermediate or final
                if (isIntermediate)
                {
                    IntermediateTranscriptionReceived?.Invoke(this, new IntermediateTranscriptionEventArgs(entry));
                }
                else
                {
                    TranscriptionReceived?.Invoke(this, new TranscriptionEventArgs(entry));
                }
            }
            catch (Exception ex)
            {
                ErrorOccurred?.Invoke($"Error processing transcription result: {ex.Message}");
            }
        }

        public void Dispose()
        {
            StopRecordingAsync().Wait();
            capture?.Dispose();
            recognizer?.Dispose();
            pushStream?.Dispose();
        }
    }
}

