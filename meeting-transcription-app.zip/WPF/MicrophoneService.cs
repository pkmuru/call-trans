using Microsoft.CognitiveServices.Speech;
using Microsoft.CognitiveServices.Speech.Audio;
using Microsoft.CognitiveServices.Speech.Transcription;
using NAudio.CoreAudioApi;
using NAudio.Wave;
using Newtonsoft.Json.Linq;
using System;
using System.Threading.Tasks;

namespace MeetingTranscriptionApp
{
    public class MicrophoneService : IDisposable
    {
        private readonly SpeechConfig speechConfig;
        private ConversationTranscriber recognizer;
        private PushAudioInputStream pushStream;
        private WaveInEvent waveIn;
        private MMDevice currentDevice;
        
        // Speaker color for visual distinction
        private readonly string MicColor = "#4F6BED"; // Blue for microphone
        
        // Event for transcription results
        public event EventHandler<TranscriptionEventArgs> TranscriptionReceived;
        public event EventHandler<IntermediateTranscriptionEventArgs> IntermediateTranscriptionReceived;
        public event Action<string> ErrorOccurred;
        
        public MicrophoneService(SpeechConfig speechConfig)
        {
            this.speechConfig = speechConfig;
        }
        
        public async Task SetDeviceAsync(MMDevice device)
        {
            // Store the device for later use
            currentDevice = device;
        }
        
        public async Task StartRecordingAsync(System.Threading.CancellationToken cancellationToken)
        {
            try
            {
                // Configure speech settings
                speechConfig.OutputFormat = OutputFormat.Detailed;
                speechConfig.SetProperty("SpeechServiceResponse_SpeakerDiarizationEnabled", "true");
                speechConfig.SetProperty(PropertyId.SpeechServiceResponse_RequestWordLevelTimestamps, "true");
                
                // Create audio stream
                var audioFormat = AudioStreamFormat.GetWaveFormatPCM(16000, 16, 1);
                pushStream = AudioInputStream.CreatePushStream(audioFormat);
                var audioConfig = AudioConfig.FromStreamInput(pushStream);
                
                // Create conversation transcriber
                recognizer = new ConversationTranscriber(speechConfig, audioConfig);
                
                // Set up event handlers for final transcription
                recognizer.Transcribed += (s, e) =>
                {
                    if (!string.IsNullOrWhiteSpace(e.Result.Text))
                    {
                        var json = e.Result.Properties.GetProperty(PropertyId.SpeechServiceResponse_JsonResult);
                        ProcessTranscriptionResult(e.Result, json, false);
                    }
                };
                
                // Set up event handlers for intermediate transcription
                recognizer.Transcribing += (s, e) =>
                {
                    if (!string.IsNullOrWhiteSpace(e.Result.Text))
                    {
                        var json = e.Result.Properties.GetProperty(PropertyId.SpeechServiceResponse_JsonResult);
                        ProcessTranscriptionResult(e.Result, json, true);
                    }
                };
                
                recognizer.Canceled += (s, e) =>
                {
                    ErrorOccurred?.Invoke($"Canceled: {e.Reason} - {e.ErrorDetails}");
                };
                
                // Start transcribing
                await recognizer.StartTranscribingAsync();
                
                // Find the device index for NAudio
                int deviceIndex = 0;
                if (currentDevice != null)
                {
                    for (int i = 0; i < WaveIn.DeviceCount; i++)
                    {
                        var capabilities = WaveIn.GetCapabilities(i);
                        if (capabilities.ProductName.Contains(currentDevice.FriendlyName))
                        {
                            deviceIndex = i;
                            break;
                        }
                    }
                }
                
                // Initialize audio capture
                waveIn = new WaveInEvent
                {
                    DeviceNumber = deviceIndex,
                    WaveFormat = new WaveFormat(16000, 16, 1)
                };
                
                // Set up data available handler
                waveIn.DataAvailable += (s, e) =>
                {
                    try
                    {
                        if (!cancellationToken.IsCancellationRequested)
                        {
                            byte[] buffer = new byte[e.BytesRecorded];
                            Array.Copy(e.Buffer, 0, buffer, 0, e.BytesRecorded);
                            pushStream.Write(buffer);
                        }
                    }
                    catch (Exception ex)
                    {
                        ErrorOccurred?.Invoke($"Audio Write Error: {ex.Message}");
                    }
                };
                
                // Start recording
                waveIn.StartRecording();
            }
            catch (Exception ex)
            {
                ErrorOccurred?.Invoke($"Microphone Capture Error: {ex.Message}");
                throw;
            }
        }
        
        public async Task StopRecordingAsync()
        {
            try
            {
                // Stop and dispose waveIn
                if (waveIn != null)
                {
                    waveIn.StopRecording();
                    waveIn.Dispose();
                    waveIn = null;
                }
                
                // Close push stream
                if (pushStream != null)
                {
                    pushStream.Close();
                    pushStream = null;
                }
                
                // Stop and dispose recognizer
                if (recognizer != null)
                {
                    await recognizer.StopTranscribingAsync();
                    recognizer.Dispose();
                    recognizer = null;
                }
            }
            catch (Exception ex)
            {
                ErrorOccurred?.Invoke($"Error stopping microphone recording: {ex.Message}");
                throw;
            }
        }
        
        private void ProcessTranscriptionResult(ConversationTranscriptionResult result, string jsonResult, bool isIntermediate)
        {
            try
            {
                // Parse the JSON to extract speaker information if available
                string speakerName = currentDevice?.FriendlyName ?? "Microphone";
                string speakerInitials = "MIC";
                int offset = 0;
                
                if (!string.IsNullOrEmpty(jsonResult))
                {
                    var json = JObject.Parse(jsonResult);
                    if (json["NBest"] is JArray nBest && nBest.Count > 0)
                    {
                        var firstResult = nBest[0];
                        if (firstResult["Speaker"] != null)
                        {
                            var speakerId = firstResult["Speaker"].ToString();
                            speakerName = $"Speaker {speakerId}";
                            speakerInitials = $"S{speakerId}";
                        }
                        
                        // Extract offset if available
                        if (firstResult["Offset"] != null)
                        {
                            if (int.TryParse(firstResult["Offset"].ToString(), out int parsedOffset))
                            {
                                offset = parsedOffset;
                            }
                        }
                    }
                }
                
                // Create transcription entry
                var entry = new TranscriptionEntry
                {
                    SpeakerName = speakerName,
                    SpeakerInitials = speakerInitials,
                    SpeakerColor = MicColor,
                    Text = result.Text,
                    Timestamp = DateTime.Now.ToString("h:mm:ss tt"),
                    Offset = offset
                };
                
                // Raise appropriate event based on whether this is intermediate or final
                if (isIntermediate)
                {
                    IntermediateTranscriptionReceived?.Invoke(this, new IntermediateTranscriptionEventArgs(entry));
                }
                else
                {
                    TranscriptionReceived?.Invoke(this, new TranscriptionEventArgs(entry));
                }
            }
            catch (Exception ex)
            {
                ErrorOccurred?.Invoke($"Error processing transcription result: {ex.Message}");
            }
        }
        
        public void Dispose()
        {
            StopRecordingAsync().Wait();
            waveIn?.Dispose();
            recognizer?.Dispose();
            pushStream?.Dispose();
        }
    }
}

